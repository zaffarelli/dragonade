window.onload = function(){
  // Here is how you would call the libary
  PanZoom(".panzoom");
}
